import os 
import csv

csvpath = os.path.join('election_data.csv')
# create a dictionary to store candidate name and vote count 
poll = {}
total_vote = 0

# open the file
with open(csvpath, newline='') as csvfile:
    csvread = csv.reader(csvfile)

    # skip the header row
    next(csvread, None)

    # store candidate name as the keys in the poll dictionary. Each name only use once
    # and for each candidate count the total vote
    for row in csvread:
        total_vote += 1

        # if name exist vote += 1
        if row[2] in poll.keys():
            poll[row[2]] = poll[row[2]]+1
        # if name not exist vote = 1
        else:
            poll[row[2]] = 1

    # Store the keys and value in poll to a seaprate list for analysis
candidate = []
votes = []
for key, value in poll.items():
    candidate.append(key)
    votes.append(value)

    # calculate % vote for each candidate
vote_percent = []
for i in votes:
    vote_percent.append(round((i/total_vote)*100, 2))

    """we have a list of candiate, a list of their correspoding vote and % vote
    In python, zip() function can help us to "zip" the 3 lists together to form a turple combine the info of the 3 list
    e.g: (('candidate1', 'num_votes1', '% vote1), ...,... ))

    """
clean_data = list(zip(candidate, votes, vote_percent))  

    # determine the winner
winner_vote = 0
for key in poll.keys():
    if poll[key] > winner_vote:
        winner = key
        winner_vote = poll[key]


    # consider if there is tie in the analysis
    """
    winner_list = []
    for name in clean_data:
        if max(votes) == name[1]:
            winner_list.append(name[0])
    winner = winner_list[0]
    if len(winner_list) > 1:
        for i in range(1, len(winner_list)):
            winner = winner + ', ' + winner_list[i]
    """
#prints to file
output_file = os.path.join('election_results.txt')

with open(output_file, 'w') as txtfile:
    txtfile.write('Election Results \n------------------------- \nTotal Votes: ' + str(total_vote) + 
                                    '\n-------------------------\n')
    for entry in clean_data:
        txtfile.write(entry[0] + ": " + str(entry[2]) +'%  (' + str(entry[1]) + ')\n')
        
    txtfile.write('------------------------- \nWinner: ' + winner + '\n-------------------------')

#prints file to terminal
with open(output_file, 'r') as readfile:
    print(readfile.read())